#!/bin/sh

mvn surefire-report:report  
