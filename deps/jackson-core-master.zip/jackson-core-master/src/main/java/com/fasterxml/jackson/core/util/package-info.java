/**
 * Utility classes used by Jackson Core functionality.
 */
package com.fasterxml.jackson.core.util;
